/**
 * 
 */
/**
 * 
 */
module MY2DGAME {
	requires java.desktop;
}